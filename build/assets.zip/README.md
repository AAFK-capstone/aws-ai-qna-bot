#Assets
static assets.

default-utterances.json
    default utterances for lex slot type

examples/documents
example QnA documents and media. 
