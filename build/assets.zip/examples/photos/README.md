# Example images
for use in response cards
must be SVG images in order to be served correctly from ApiGateway. 
