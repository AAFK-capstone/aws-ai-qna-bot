# Proxy-es
This lambda function is used to proxy request from apigateway to elasticsearch

## Tests
test are running using:
```shell
npm test
```
or
```shell
npm unit {{test-name}}
```

