exports.handler=require('/opt/lib/cfn').resource
