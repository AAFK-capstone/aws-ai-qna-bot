# Lex-Build Lambda
Rebuilds AWS Lex Bot

## Tests
test are running using:
```shell
npm test
```
or
```shell
npm unit {{test-name}}
```

