individual components needed for lex-build
