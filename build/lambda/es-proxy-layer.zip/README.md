# ES Proxy layer
This layer contains library lambda functions which will be used by es-proxy.
The individual functions are in ./lib 