lex example request object and schema for response objects
