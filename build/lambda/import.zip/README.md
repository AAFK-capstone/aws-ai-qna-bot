# Import Lambda
this lambda imports QnAs from S3 into elasticsearch,

## Tests
test are run using:
```shell
npm test
```
or
```shell
npm unit {{test-name}}
```

