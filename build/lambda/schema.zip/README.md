# Import Lambda
this lambda returns the schema for QID types used in Content designer


